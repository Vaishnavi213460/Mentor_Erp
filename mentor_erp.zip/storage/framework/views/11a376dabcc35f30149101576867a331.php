

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Inventory Overview</h2>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>SKU</th>
                    <th>Product Name</th>
                    <th>Unit Cost</th>
                    <th>Current Stock</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->sku); ?></td>
                    <td><?php echo e($product->name); ?></td>
                    <td>$<?php echo e(number_format($product->unit_cost, 2)); ?></td>
                    <td><?php echo e($product->stock_quantity); ?></td>
                    <td>
                        <?php if($product->stock_quantity < $product->low_stock_threshold): ?>
                            <span class="badge bg-danger">Low Stock</span>
                        <?php else: ?>
                            <span class="badge bg-success">In Stock</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">
    <?php echo e($products->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\VAISH-FILES\CODE PRACTICE\mentor_erp\resources\views/inventory/index.blade.php ENDPATH**/ ?>