

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Executive Dashboard</h2>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white shadow-sm">
            <div class="card-body">
                <h6 class="card-title">Total Active Products</h6>
                <h3 class="fw-bold"><?php echo e($totalActiveProducts); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning text-dark shadow-sm">
            <div class="card-body">
                <h6 class="card-title">Low Stock Alerts</h6>
                <h3 class="fw-bold"><?php echo e($lowStockCount); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white shadow-sm">
            <div class="card-body">
                <h6 class="card-title">Total Expenditure</h6>
                <h3 class="fw-bold">$<?php echo e(number_format($totalExpenditure, 2)); ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white">
        <h5 class="mb-0">Latest Purchase Orders</h5>
    </div>
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>PO Number</th>
                    <th>Supplier</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $latestOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $po): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($po->po_number); ?></td>
                    <td><?php echo e($po->supplier->name); ?></td>
                    <td>$<?php echo e(number_format($po->total_amount, 2)); ?></td>
                    <td>
                        <span class="badge bg-<?php echo e(match($po->status->value) {
                            'DRAFT' => 'secondary',
                            'APPROVED' => 'primary',
                            'RECEIVED' => 'success',
                            'CANCELLED' => 'danger'
                        }); ?>">
                            <?php echo e($po->status->value); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('purchase-orders.show', $po->id)); ?>" class="btn btn-sm btn-outline-primary">View</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\VAISH-FILES\CODE PRACTICE\mentor_erp\resources\views/dashboard.blade.php ENDPATH**/ ?>