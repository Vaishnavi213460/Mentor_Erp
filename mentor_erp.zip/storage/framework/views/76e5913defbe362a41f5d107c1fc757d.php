

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Purchase Order: <?php echo e($purchaseOrder->po_number); ?></h2>
    <div>
        <?php if($purchaseOrder->status->value === 'DRAFT'): ?>
            <form action="<?php echo e(route('purchase-orders.status', $purchaseOrder->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="status" value="APPROVED">
                <button class="btn btn-primary">Approve Order</button>
            </form>
            <form action="<?php echo e(route('purchase-orders.status', $purchaseOrder->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="status" value="CANCELLED">
                <button class="btn btn-danger">Cancel Order</button>
            </form>
        <?php elseif($purchaseOrder->status->value === 'APPROVED'): ?>
            <form action="<?php echo e(route('purchase-orders.status', $purchaseOrder->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="status" value="RECEIVED">
                <button class="btn btn-success">Mark as Received</button>
            </form>
            <form action="<?php echo e(route('purchase-orders.status', $purchaseOrder->id)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                <input type="hidden" name="status" value="CANCELLED">
                <button class="btn btn-danger">Cancel Order</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h5>Supplier Info</h5>
                <p class="mb-1"><strong>Name:</strong> <?php echo e($purchaseOrder->supplier->name); ?></p>
                <p class="mb-1"><strong>Email:</strong> <?php echo e($purchaseOrder->supplier->email); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body">
                <h5>Order Summary</h5>
                <p class="mb-1"><strong>Status:</strong> <span class="badge bg-secondary"><?php echo e($purchaseOrder->status->value); ?></span></p>
                <p class="mb-1"><strong>Total Amount:</strong> $<?php echo e(number_format($purchaseOrder->total_amount, 2)); ?></p>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header bg-white"><h5 class="mb-0">Line Items</h5></div>
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>SKU</th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $purchaseOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->product->name); ?></td>
                    <td><?php echo e($item->product->sku); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td>$<?php echo e(number_format($item->unit_price, 2)); ?></td>
                    <td>$<?php echo e(number_format($item->subtotal, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\VAISH-FILES\CODE PRACTICE\mentor_erp\resources\views/purchase_orders/show.blade.php ENDPATH**/ ?>